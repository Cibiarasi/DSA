import java.util.*;
public class rotate {
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int arr[]=new int[n];
        for(int i=0;i<n;i++){
            arr[i]=sc.nextInt();
        }
       
        int arr2[]= new int[n];
        for(int i=0;i<n;i++){
            if(i>=1){
                arr2[i-1]=arr[i];
            }
            if(i==0){
                arr2[n-1]=arr[i];
            }
          
        }
        for(int i=0;i<n;i++){
            System.out.print(arr2[i]);
        }
    }
    
}
