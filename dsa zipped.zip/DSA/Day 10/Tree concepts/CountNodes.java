import java.util.*;
class Node{
    int val;
    Node right;
    Node left;
    Node(int val){
        this.val=val;
    }
}
public class CountNodes {
    public static int count(Node root){
        if(root==null){
            return 0;
        }
        return 1 + count(root.left) + count(root.right);
    }
    /**
     * @param args
     */
    public static void main(String[] args){
        Node root=new Node(10);
        root.left=new Node(8);
        root.left.left=new Node(5);
        // root.right=new Node(30);

        System.out.print(count(root));
    }
    
}
