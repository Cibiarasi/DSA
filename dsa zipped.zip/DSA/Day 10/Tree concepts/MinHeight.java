class Node{
    int val;
    Node right;
    Node left;
    Node(int val){
        this.val = val;
    }
}
public class MinHeight {
    public static int minheight(Node root){
        if(root == null){
            return 0;
        }
        if(root.left == null){
            return 1 + minheight(root.right);
        }
        if(root.right == null){
            return 1 + minheight(root.left);
        }
        int leftheight = minheight(root.left);
        int rightheight = minheight(root.right);
        return 1 + Math.min(leftheight, rightheight);
    }
    public static void main(String[] args){
        Node root = new Node(10);
        root.left = new Node(9);
        root.left.left = new Node(3);
        root.left.left=new Node(2);
        root.right = new Node(20);
        root.right.right=new Node(7);
        System.out.print(minheight(root));
    }
}
