import java.util.*;
class Node{
    int val;
    Node left;
    Node right;
    Node(int val){
        this.val=val;
    }
}
public class Preorder {
    public static void preorder(Node root){
        if(root==null){
            return;
        }
        System.out.print(root.val+" ");
        preorder(root.left);
        preorder(root.right);

    }
    public static void main(String[] args){
        Node root=new Node(10);
        root.left=new Node(8);
        root.right=new Node(30);
        root.left.left=new Node(3);
        root.right.right=new Node(33);
        preorder(root);
    }
    
}
