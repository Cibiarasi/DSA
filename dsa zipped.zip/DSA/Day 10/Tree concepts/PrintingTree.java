import java.util.*;
class Node{
    int val;
    Node left;
    Node right;
    Node(int val){
        this.val=val;
    }
   
}

public class PrintingTree{
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        Node root=new Node(10);
        root.left=new Node(5);
        root.right=new Node(15);
        System.out.print(root.val + " " + root.left.val + " " + root.right.val);
    }
    
}