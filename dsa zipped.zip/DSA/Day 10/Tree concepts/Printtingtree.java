import java.util.*;
public class Printtingtree{
    static  class Node{
        int val;
        Node left;
        Node right;
        Node(int val){
            this.val=val;
        }
    }
    public static void main(String[] args){
      
        Node root=new Node(10);
        root.left=new Node(9);
        root.right=new Node(30);
        System.out.print(root.val+" "+root.left.val+" "+root.right.val);
    }
}