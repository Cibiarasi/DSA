import java.util.*;
class Node{
    int val;
    Node right;
    Node left;
    Node(int val){
        this.val=val;
    }

}
public class SumOfRoots {
    public static int sum(Node root){
        if(root==null){
            return 0;
        }
        return root.val+sum(root.left)+sum(root.right);
    }
    public static void main(String[] args){
        Node root=new Node(1);
        root.left=new Node(2);
        root.right=new Node(9);
        System.out.print(sum(root));
    }
    
}
