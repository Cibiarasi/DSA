import java.util.*;
public class Addmax {
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int arr[]=new int[n];
        for(int i=0;i<n;i++){
            arr[i]=sc.nextInt();
        }
        int max=0;
        for(int i=0;i<n;i++){
            int val=i+arr[i];
            max=Math.max(max,val);

        }
        System.out.println(max);
    }
    
}
