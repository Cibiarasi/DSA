import java.util.*;
public enum Canjump {
    public boolean canjumpval(int [] arr,int n){
       
        for(int i=0;i<arr.length-1;i++){
            if(i+arr[i]>=arr.length){
                return true;
                break;
            }

            

        }

        return false;
    }
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int arr[]=new int[n];
        for(int i=0;i<n;i++){
            arr[i]=sc.nextInt();
        }
        System.out.println(canjumpval(arr,n));

    }
    
}
