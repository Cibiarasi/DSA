import java.util.*;
public class TraveringArray{
    public static void main(String[] args){
        Scanner sc=new Scanner (System.in);
        int n=sc.nextInt();
        int arr[]=new int[4];
        for(int i=0;i<n;i++){
            arr[i]=sc.nextInt();

        }
        for(int each: arr){
            System.out.println(each);
        }
    }
}