import java.util.*;
public class Reverse {
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        int arr[]=new int[]{1,2,3,4,5};
        int index=0;
        int newindex=arr.length-1;
        while(index<newindex){
            int temp=arr[newindex];
            arr[newindex]=arr[index];
           arr[index]=temp;
            newindex--;
            index++;

        }
        for(int each:arr){
            System.out.print(each+" ");
        }

    }
    
}
