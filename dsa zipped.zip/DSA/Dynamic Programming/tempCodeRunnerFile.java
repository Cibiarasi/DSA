import java.util.*;
public class Recur {

    public static void main(String[] args){
        public static int fun(int n){
            if(n==0){