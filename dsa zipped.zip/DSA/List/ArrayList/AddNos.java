import java.util.*;
public class AddNos{
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        ArrayList<Integer> list=new ArrayList<>();
        list.add(1);
        list.add(2);
        System.out.print(list);
    }
}