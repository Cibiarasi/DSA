import java.util.*;
public class Avg {
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        ArrayList<Integer> list=new ArrayList<>(Arrays.asList(1,2,3,4,5));
        int sum=0;
        for(int each:list){
            sum+=each;
            // if(list.contains(3)){
            //     System.out.println("true");
            //     break;
            // }
        }
        int avg=sum/list.size();
        System.out.print(avg);
        
    }
    
}
