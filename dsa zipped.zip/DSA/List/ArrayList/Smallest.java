import java.util.*;
public class Smallest {
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        ArrayList<Integer> list=new ArrayList<>();
        list.add(1);
        list.add(2);
        list.add(3);
        list.add(4);
        int min=list.get(0);
        for(int each:list){
            if(each<min){
                min=each;
            }
        }
        System.out.print(min);
    }
    
}