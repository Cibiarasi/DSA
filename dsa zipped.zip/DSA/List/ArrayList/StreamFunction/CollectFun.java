import java.util.*;
import java.util.stream.Collectors;

public class CollectFun {
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        ArrayList<Integer> list=new ArrayList<>(Arrays.asList(1,2,3,4,5));
        List<Integer> even=list.stream().filter(x-> x%2==0).collect(Collectors.toList());
        System.out.print(even);
    }
    
}
