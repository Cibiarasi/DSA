import java.util.*;
public class PrintStatement {
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        ArrayList<Integer> list=new ArrayList<>(Arrays.asList(1,2,3,4,5,6));
        list.stream().forEach(System.out::print);


    }
    
}
