import java.util.*;

public class filterFun {
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        ArrayList<Integer> list=new ArrayList<>(Arrays.asList(1,2,3,4,5));
        list.stream().filter(x-> x%2==0).forEach(System.out::print);
    }
    
}
