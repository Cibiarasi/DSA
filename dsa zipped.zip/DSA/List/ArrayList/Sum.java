import java.util.*;
public class Sum {
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        ArrayList<Integer> list=new ArrayList<>(Arrays.asList(1,2,3,4,5,6));
        int sum=0;
        for(int each: list){
            sum+=each;
        }
        System.out.print(sum);
    }
    
}
