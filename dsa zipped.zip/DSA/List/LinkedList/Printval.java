import java.util.*;
public class Printval{
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        LinkedList<Integer> list =new LinkedList<Integer>();
        list.add(10);
        list.add(20);
        list.add(30);
        System.out.print(list);

    }
}