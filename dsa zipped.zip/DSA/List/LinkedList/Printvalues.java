import java.util.*;
public class Printvalues