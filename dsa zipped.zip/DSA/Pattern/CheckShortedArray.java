import java.util.*;
class Solution{
    public boolean Issorted(int[] arr,int n){
        for(int i=1;i<n;i++){
            if(arr[i]<arr[i-1]){
                return false;

            }
           
        }
        return true;

    }
}
public class CheckShortedArray{
    public static void main(String[]args){
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int arr[]=new int[n];
        for(int i=0;i<n;i++){
            arr[i]=sc.nextInt();
        }
        Solution obj= new Solution();
        System.out.print(obj.Issorted(arr,n)? "true":"false");
    }
}