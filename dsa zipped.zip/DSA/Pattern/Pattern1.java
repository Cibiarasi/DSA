import java.util.*;
public class Pattern1{
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        
    }
}