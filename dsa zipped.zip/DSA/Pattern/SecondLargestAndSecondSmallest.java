import java.util.*;
public class SecondLargestAndSecondSmallest{
    public static void Getvalue(int [] arr,int n){
    int min1=Integer.MAX_VALUE;
        int min2=Integer.MAX_VALUE;
        int max1=Integer.MIN_VALUE;
        int max2=Integer.MIN_VALUE;
           for(int i=0;i<n;i++){
            if(arr[i]>max1){
                max2=max1;
                max1=arr[i];
            }
            else if(arr[i]>max2 && arr[i]!=max1){
                max2=arr[i];
            }
            if(arr[i]<min1){
                min2=min1;
                min1=arr[i];
            }
            else if(arr[i]<min2 && arr[i]!=min1){
                min2=arr[i];
            }
        }
        System.out.println("min value: "+min1+" "+min2);
        System.out.print("max value: "+max1+" "+max2);

    }


    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int arr[]=new int[n];
        
        for(int i=0;i<n;i++){
            arr[i]=sc.nextInt();

        }
        Getvalue(arr,n);
     
    }
}
